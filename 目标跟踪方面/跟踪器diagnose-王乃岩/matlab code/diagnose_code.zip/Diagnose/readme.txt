This is the implementation of paper "Understanding and Diagnosing Visual Tracking Systems" (ICCV15')
If you have any questions, please contact winsty@gmail.com

To use the code, follow the instruction in http://visual-tracking.net/ to integrate it into the toolkit.
The parameters are all set in config.m and configGlobalParam.m. Currently, it is set to the best combination without ensemble post-processor. 
