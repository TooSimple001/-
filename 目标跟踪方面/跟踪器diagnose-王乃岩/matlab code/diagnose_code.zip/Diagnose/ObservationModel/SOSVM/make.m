% mex CFLAGS="-O3 -march=nocona -Wall" -largeArrayDims mexSOSVMLearn.cpp LaRank.cpp Config.cpp
mex CFLAGS="-O3 -march=nocona -Wall" mexSOSVMLearn.cpp LaRank.cpp Config.cpp