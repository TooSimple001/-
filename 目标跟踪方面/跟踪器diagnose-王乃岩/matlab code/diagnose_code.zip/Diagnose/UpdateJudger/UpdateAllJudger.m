function shouldUpdate = UpdateAllJudger(model, opt)
shouldUpdate = true;